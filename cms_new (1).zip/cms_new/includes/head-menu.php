<nav id="student_nav" class="navbar navbar-inverse navbar-embossed" role="navigation">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-01">
                <span class="sr-only">Toggle navigation</span>
              </button>
              <a class="navbar-brand" href="/cms/head/">Home</a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse-01">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="/cms/head/manage-club.php">Manage Club</a></li>
                <li><a href="/cms/head/edit-credentials.php">Update Credentials</a></li>
                <li><a href="/cms/logout.php"><span class="" style="float:right">Log Out</span></a></li>
               </ul>
               <form class="navbar-form navbar-right" action="#" role="search">
                <div class="form-group">
                </div>
              </form>
            </div>
</nav>