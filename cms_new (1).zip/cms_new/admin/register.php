<?php 
    getHeader(); 
    include_once('home-menu.php');
?>


<div class="container">
	<div class="row">
        <center><h1>Register As Admin :</h1></center>
            <hr><br>
		<div class="col-md-8 col-md-offset-2">

					<form class="form-horizontal" role="form" method="POST" action="">

                        <div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">User Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="name" placeholder="User Name" value="" autocomplete="off">
							</div>
						</div>

                        <div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">Email</label>
							<div class="col-md-6">
								<input type="email" class="form-control" name="email" placeholder="Email" value="" autocomplete="off">
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password" placeholder="Password" value="" >
							</div>
						</div>





						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<button type="submit" name="submit"
                                    style="width:100%;background:green;border-color:green" class="btn btn-primary">
                                    Register</button>

							</div>
						</div>

<?php if(isset($_POST['submit'])){
                       
    extract($_POST);

					if($name == '' || $email == '' ||  $password == ''  ){
                            ?><div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <li>You cannot leave the fields blank!</li>
                                </ul>
                            </div>
                        
            <?php 
                    }elseif(!preg_match("/(sanjivani.org)/i", $email)){
                        
                ?>
                                <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                    <ul>
                                        <li> You must have to use a @sanjivani.org email id</li>
                                    </ul>
                                </div> 
                  
                        <?php
                    }else{

            $clubId = queryMySQL("SELECT `id` FROM `clubs` WHERE `name` = '$club'")->fetch_assoc()['id'];   
                        
            $res = queryMySQL("SELECT * FROM `heads` WHERE `email` = 'email'");            
            if($res->num_rows > 0){
                
                queryMySQL("UPDATE `heads` SET `firstname`='$firstname',`lastname`='$lastname',`email`='$email',`password`='$password' WHERE `club_id` = '$clubId'");
                echo "<span class='alert alert-danger'> Sorry Admin With Same Email Already Exists!</span> ";                
                                
            }else{
                QueryMySQL("INSERT INTO `admins`(`name`, `email`, `password`) VALUES ('$name','$email','$password')");
    
                $result = queryMySQL("SELECT * FROM `admins` WHERE `email` = '$email' AND `password` = '$password'" );
                if($result->num_rows > 0){
                        $id = $result->fetch_assoc()['id'];
                        $username = $result->fetch_assoc()['name'];
                        $email = $result->fetch_assoc()['email'];
                        logIn($id, $username, $email,'admin');
                        echo "<script>window.location = '/cms/admin/'</script>";
                }
            echo "<span class='alert alert-success'> Added Successfully!</span> ";
             }
                        
                        

        }
}
                        ?>
					</form>
				</div>
    </div>
</div>



<?php getFooter(); ?>