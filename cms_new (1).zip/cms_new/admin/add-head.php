<?php 
    getHeader(); 
    adminAccess();
    include_once('admin-menu.php');
?>


<div class="container">
	<div class="row">
        <center><h1>Add A Head To Club :</h1></center>
            <hr><br>
		<div class="col-md-8 col-md-offset-2">

					<form class="form-horizontal" role="form" method="POST" action="">

                        <div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">First Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="firstname" placeholder="First Name" value="" autocomplete="off">
							</div>
						</div>

                        <div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">Last Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="lastname" placeholder="Last Name" value="" autocomplete="off">
							</div>
						</div>

                        <div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">Email</label>
							<div class="col-md-6">
								<input type="email" class="form-control" name="email" placeholder="Email" value="" autocomplete="off">
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Club</label>
							<div class="col-md-6">
								<select class="form-control" name="club">
                                    <optgroup>
                                <?php $clubs = queryMySQL('SELECT `name` FROM `clubs` WHERE 1');
                                        foreach($clubs as $club){
                                            echo "<option>".$club['name']."</option>";
                                        } 
                                ?>
                                        
                                    </optgroup>
                                </select>
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password" placeholder="Password" value="" >
							</div>
						</div>





						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<button type="submit" name="submit"
                                    style="width:100%;background:green;border-color:green" class="btn btn-primary">
                                    Add Exam</button>

							</div>
						</div>

<?php if(isset($_POST['submit'])){
                       
    extract($_POST);

					if($firstname == '' || $lastname == '' || $email == '' ||  $password == '' || $club =='' ){
                            ?><div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <li>You cannot leave the fields blank!</li>
                                </ul>
                            </div>
            <?php     }elseif(!preg_match("/(sanjivani.org)/i", $email)){
                        
                
                            echo "You must have to use a @sanjivani.org email id";        
                        
                    }else{

            $clubId = queryMySQL("SELECT `id` FROM `clubs` WHERE `name` = '$club'")->fetch_assoc()['id'];   
                        
            $res = queryMySQL("SELECT * FROM `heads` WHERE `club_id` = '$clubId'");            
            if($res->num_rows > 0){
                
                echo "<span class='alert alert-danger'> There's already a head alloted for this club :-/ Please delete previous one.</span>";
                
            }else{
                
            queryMySQL("INSERT INTO `heads`(`club_id`, `firstname`, `lastname`, `email`, `password`) VALUES ('$clubId','$firstname','$lastname','$email','$password')");
    
            echo "<span class='alert alert-success'> Added Successfully!</span> ";
             }
                        
                        

        }
}
                        ?>
					</form>
				</div>
    </div>
</div>



<?php getFooter(); ?>