
<?php getHeader();
        
    if(isAdmin()){
        header('Location: /cms/admin/');
    }else if(isStudent()){
        header('Location: /cms/student/');
        
    }else if(isHead()){
        header("Location: /cms/head");
    }

include_once("home-menu.php");
?>
<div class="container">
	<div class="row">
        <center><h1 class="subtle-heading">Club Head LogIn </h1></center>
            <hr><br>
		<div class="col-md-8 col-md-offset-2">

					<form class="form-horizontal" role="form" method="POST" action="#">
						<input type="hidden" name="_token" value="">

						<div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">E-Mail Address:</label>
							<div class="col-md-6">
								<input type="email" class="form-control" name="email" value="">
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password">
							</div>
						</div>


						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
								<button type="submit" name="submit" style="width:100%;background:green;border-color:green" class="btn btn-primary">Login</button>
<a href="register.php" style="left:7em">Or Register</a>
							</div>
						</div>
                        

<?php if(isset($_POST['submit'])) { 
            $email  = $_POST['email'];
            $password = $_POST['password'];
            if($email =='' || $password == ''){ ?>    

                                <div class="alert alert-danger">
                                        <strong>Whoops!</strong> You cannot keep the fields blank!<br><br>
                                </div>
            <?php } 
            else {
                $result = queryMySQL("SELECT * FROM `heads` WHERE `email` = '$email' AND `password` = '$password'" );
                if($result->num_rows > 0){
                        $id = $result->fetch_assoc()['id'];
                        $username = $result->fetch_assoc()['name'];
                        $email = $result->fetch_assoc()['email'];
                        
                        logIn($id, $username, $email,'head');
                        header('Location: /cms/head/');
                        
                        ?>
                            <div class="alert alert-success">
                                            <strong> Great! You've successfully logged in!</strong><br><br>
                            </div>
            <?php    } else { ?> 

                            <div class="alert alert-danger">
                                            <strong>Whoops!</strong> You've entered wrong credentials!<br><br>
                            </div>

            <?php }  ?>
                
                
        <?php    } } ?>

					</form>
				</div>
    </div>
</div>
<?php getFooter(); ?>