<?php getHeader();
  include_once('home-menu.php');

?>

<div class="container">
	<div class="row">
        <center><h4>Register As A Student:</h4></center>
            <hr><br>
		<div class="col-md-8 col-md-offset-2">

					<form class="form-horizontal" role="form" method="POST" action="register.php" enctype="multipart/form-data">
						<div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">First Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="firstname" value="">
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-4 control-label">Last Name</label>
							<div class="col-md-6">
								<input type="text" class="form-control" name="lastname">
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Email Address</label>
							<div class="col-md-6">
								<input type="email" class="form-control" name="email">
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Class</label>
							<div class="col-md-6">
                                <select class="form-control" name="class">
                                    <optgroup>
                                        <option>FY</option>
                                        <option>SY</option>
                                        <option>TY</option>
                                    </optgroup>
                                </select>
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Extra Info</label>
							<div class="col-md-6">
                                <textarea class="form-control" name="info"></textarea>
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">Mo. No.</label>
							<div class="col-md-6">
                                <input type="text" class="form-control" name="mn" >
							</div>
						</div>

                        <div class="form-group">
							<label class="col-md-4 control-label">DOB</label>
							<div class="col-md-6">
                                <input type="date" class="form-control" name="DOB">
							</div>
						</div>
                        <div class="form-group">
							<label class="col-md-4 control-label">Select Clubs (Max 3)</label>
                            <div class="col-md-6">
                            <?php 
                                
                                $clubs = queryMySQL("SELECT * FROM `clubs` WHERE 1");
                                $i = 1;
                                foreach($clubs as $c){
                                ?>
                            <input type="checkbox" class="one-checkbox" name="check_list[]" value="<?php echo $c['id']; ?>">
                                <?php echo " ".$c['name']."<br>";
                         
                            
                             } ?>
                            </div>
						</div>

 						<div class="form-group success" style="border-color:green">
							<label class="col-md-4 control-label">Profile Picture</label>
							<div class="col-md-6">
								<input type="file" class="form-control" name="image" >
							</div>
						</div>
        
                        <div class="form-group">
							<label class="col-md-4 control-label">Password</label>
							<div class="col-md-6">
								<input type="password" class="form-control" name="password">
							</div>
						</div>



						<div class="form-group">
							<div class="col-md-6 col-md-offset-4">
				<button type="submit"  name="submit" style="width:100%;background:green;border-color:green" class="btn btn-primary">
                                    Register</button>

							</div>
						</div>

                        
<script>
var limit = 3;

$('input.one-checkbox').on('change', function(evt) {
   if($(this).siblings(':checked').length >= limit) {
       this.checked = false;
   }
});
</script>                        
                        
                        
<?php if(isset($_POST['submit'])){
                extract($_POST);
                if($firstname == '' || $lastname == '' || $email == '' || $class == '' || $password == '' || $DOB == '' || $mn == '' || $info == ''){
                
                            ?><div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <li> You cannot leave the fields empty </li>
            <?php        
            }elseif($_FILES['image']['size'] == 0){
                        ?>
                        <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <li>Please select a profile picture</li>
                                </ul>
                        </div>                                        
                        <?php            
                    }else{
                    
                    $res = queryMySQL("SELECT * FROM `students` WHERE `email` = '$email'");
                    if($res->num_rows>0){
                        ?>
                                
                                    <div class="alert alert-danger">
                                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                    <ul>
                                        <li> There's Already A User Registered With Same Email </li>
                                    </ul>
                                </div>
                                    <?php
                        
                    } else{
                     
            $res = queryMySQL("INSERT INTO `students`(`firstname`, `lastname`, `email`, `class`, `info`, `password`, `DOB`, `mn`) VALUES ('$firstname','$lastname','$email','$class','$info','$password','$DOB','$mn')");
                        
                        $insert_id = insertId();
                        
                        if(isset($_FILES['image'])){
                            $file_temp = $_FILES['image']['tmp_name'];
                            $target_dir = $insert_id.".jpg";
                            move_uploaded_file($file_temp,'../dist/img/students/'.$target_dir);
                        }else{
                            echo "Please Select A Profile Picture!";
                        }
                        

                            $i = 1;
                            $clubs = array();
                            foreach($_POST['check_list'] as $check) {

                                if(isset($check)){
                                    $clubs[$i] = $check;
                                    $tmp = $clubs["$i"];
                                    queryMySQL("INSERT INTO `memberships`(`student_id`, `club_id`) VALUES ('$insert_id','$tmp')");
                                    $i++;
                                }
                            }
                        
                $result = queryMySQL("SELECT * FROM `students` WHERE `email` = '$email' AND `password` = '$password'" );
                if($result->num_rows > 0){ 
                        foreach($result as $res){
                            print_r($res);
                            $id = $res['id'];
                            $username = $res['firstname'].' '.$res['lastname'];
                            echo $username;
                        }
                        logIn($id, $username,$email,'student');
                        ?>
                                    <script>window.location  = '/cms/student'</script>
                                    <?php
                        
                        
                        
                            echo "<span class='alert alert-success'>Added Successfully! </span>";
                    
                    
                    
                    
                    
                    }
                      
                    
                }
}
}
                        
                        ?>
					</form>
				</div>
    </div>
</div>



<?php getFooter(); ?>